#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#ifndef NAIF_H
#define NAIF_H

char** MappingToSet(char * nomfichier);
int Min(int a, int b);
int notegal(char a , char b);
int Leven(char *x,char *y);
int	max(int a,int b);
char** purge(char* nomfichier);

#endif
